
<script type="text/javascript">

    // Question 01
    function addNumbers(num1, num2){
        return (num1 + num2);
    }
    const sumResult = addNumbers(5, 10);
    console.log("The sum: " + sumResult);

    // Question 02
    function squareOfNumber(num){
        return (num * num);
    }
    const squareResult = squareOfNumber(5);
    console.log("The square: " + squareResult);

    // Question 03
    function areaOfRectangle(length, width){
        return (length * width);
    }
    const area = areaOfRectangle(20, 30);
    console.log("The area: " + area);

    // Question 04
    function degreeConverterToCelsius(fahrenheit){
        return ((fahrenheit - 32) * (5 / 9));
    }
    const tempCelsius = degreeConverterToCelsius(75);
    console.log("The temperature in Celsius: " + tempCelsius);

    function degreeConverterToFahrenheit(celsius){
        return ((celsius * (9 / 5)) + 32);
    }
    const tempFahrenheit = degreeConverterToFahrenheit(75);
    console.log("The temperature in Fahrenheit: " + tempFahrenheit);

    // Question 05
    function factorial(n) {
        if (n === 0 || n === 1) {
            return 1;
        }
        return n * factorial(n - 1);
    }
    const factorialResult = factorial(24);
    console.log("The factorial: " + factorialResult);

    // Question 06
    function findMax(a, b, c) {
        let max;
        if (a > b && a > c) {
            max = a;
        } else if (b > c) {
            max = b;
        } else {
            max = c;
        }
        return max;
    }
    const maxResult = findMax(10, 25, 15);
    console.log("The maximum number is: " + maxResult); 

    // Question 07
    function calculateAverage(numbers) {
        let total = 0;
        let i = 0;
        while (i < numbers.length) {
            total += numbers[i];
            i++;
        }
        return total / numbers.length;
    }
    const numbersArray = [10, 20, 30, 40, 50];
    const averageResult = calculateAverage(numbersArray);
    console.log("The average is: " + averageResult);

    // Question 08
    function circleArea(radius) {
        return radius * radius * (22 / 7);
    }
    const areaResult = circleArea(7);
    console.log("The area of the circle is: " + areaResult.toFixed(2));

    // Question 09
    function power(base, exponent) {
        let result = 1;
        for (let i = 0; i < exponent; i++) {
            result *= base;
        }
        return result;
    }
    const powerResult = power(2, 5);
    console.log("2 raised to the power of 5 is: " + powerResult);

    // Question 10
    function isPrime(num) {
        if (num <= 1) {
            return false;
        }
        for (let i = 2; i <= Math.sqrt(num); i++) {
            if (num % i === 0) {
                return false;
            }
        }
        return true;
    }
    const isPrimeResult = isPrime(29);
    console.log("Is 29 a prime number? " + isPrimeResult);

</script>
